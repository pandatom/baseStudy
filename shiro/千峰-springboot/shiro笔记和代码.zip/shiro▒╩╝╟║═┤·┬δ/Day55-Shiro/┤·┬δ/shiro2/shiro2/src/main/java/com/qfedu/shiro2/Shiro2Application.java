package com.qfedu.shiro2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Shiro2Application {

    public static void main(String[] args) {
        SpringApplication.run(Shiro2Application.class, args);
    }

}
