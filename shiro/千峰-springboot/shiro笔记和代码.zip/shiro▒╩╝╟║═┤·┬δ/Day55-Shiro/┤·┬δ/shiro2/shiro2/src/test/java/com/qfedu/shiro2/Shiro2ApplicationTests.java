package com.qfedu.shiro2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Shiro2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
