[![HitCount](http://hits.dwyl.com/saika952/SSM-CRUD.svg)](http://hits.dwyl.com/saika952/SSM-CRUD)

# SSM-CRUD

根据[b站尚硅谷](https://www.bilibili.com/video/BV17W411g7zP)视频教程实现的基于SSM框架（Spring+SpringMVC+MyBatis）的后台员工管理系统

在原有基础上，增加了查询功能。可以根据输入的内容查询员工姓名。
